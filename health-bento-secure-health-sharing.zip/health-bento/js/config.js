/* Copy your Supabase project URL and publishable/anon key here for local development.
   Never place a service_role key in this browser file. */
window.CAREBRIDGE_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"
};
